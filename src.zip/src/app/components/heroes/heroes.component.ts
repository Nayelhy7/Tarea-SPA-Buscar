import { Component } from '@angular/core';
import { HeroesService } from '../heroes.service';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrl: './heroes.component.css'
})
export class HeroesComponent {
  
  heroes: any[] = [];

  constructor(private_heroeService: HeroesService) {

  }
  ngOnInit():void{
    this.heroes= this._heroeService.getHeroes();
    console.log(this.heroes);
  }
}
